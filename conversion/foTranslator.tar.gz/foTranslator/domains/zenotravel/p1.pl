:- consult(initial1).

goal(eventually(always(at(person1, city3)))).
