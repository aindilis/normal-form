:- consult(initial1).

goal(and(eventually(and(at(person1, city2), next(eventually(at(person1, city3))))), eventually(and(at(person2, city3), next(eventually(at(person2, city2))))))).
