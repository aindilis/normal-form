:- consult(initial1).

goal(exists(c, and(city(c), eventually(and(and(at(person1, c), and(at(person2, c), at(person3, c))), eventually(always(and(at(person1, city4), at(person2, city3))))))))).
