:- consult(initial1).

goal(exists(c, and(city(c), eventually(and(at(person1, c), and(at(person2, c), and(at(person3, c), eventually(always(and(at(person1, city4), and(at(person2, city3), at(person1, city1)))))))))))).
