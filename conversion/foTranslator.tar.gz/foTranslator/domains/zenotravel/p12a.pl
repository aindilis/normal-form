:- consult(initial1).

goal(and(until(at(plane2, city3), and(at(plane2, city2), until(at(plane2, city2), at(plane2, city3)))), and(until(at(plane1, city0), and(at(plane1, city2), until(at(plane1, city2), at(plane1, city0)))), and(eventually(always(at(person1, city3))), eventually(always(at(person3, city3))))))).
