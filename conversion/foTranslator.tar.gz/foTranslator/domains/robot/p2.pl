:- consult(robot_init2).

goal(and(or(next(next(next(next(at(obj1,r4))))),
	    next(next(next(next(next(at(obj1,r4))))))),
	 always(or(not(final),and(at(robot,c1),at(obj1,r2)))))).

